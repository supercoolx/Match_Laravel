<?php

namespace App\Models\profile;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProfileWriting extends Model
{
    use HasFactory;
    
    public $timestamps = false;
}
