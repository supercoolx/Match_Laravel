@extends('layout.app')

@section('content')
@endsection

@section('script')
@endsection
