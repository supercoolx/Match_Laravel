@extends('layout.app')

@section('content')
    <p></p>
@endsection

@section('script')
@endsection
