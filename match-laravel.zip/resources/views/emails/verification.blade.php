<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
<p>以下のリンクより、パスワードの再設定を行ってください。</p>

<a href="#">パスワードをリセットする</a>

<p>このメールは Scope株式会社のサービス をご利用いただいているお客さまに送信しています。</p>
<p>送信専用アドレスのため、ご返信いただいても、ご返事ができません。</p>
<p>あらかじめご了承ください。</p>

</body>
</html>